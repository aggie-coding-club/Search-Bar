# Search-Bar
Implement a search bar for some topic.
