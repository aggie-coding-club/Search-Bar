import csv
import pathlib

class filterRoblox(object):
    def normalize(self, arr):
        maxElement = max(arr)

        for i in range(len(arr)):
            arr[i] = arr[i] / maxElement

    def filter(self, fileName, columnIndices, weights):
        if(len(weights) != len(columnIndices)):
            raise ValueError('The number of weights do not match the number of columns')

        allData = []
        with open(fileName, 'r', encoding='utf8') as readFile:
            lines = csv.reader(readFile, delimiter = ',')

            for row in lines:
                allData.append(row)


        # Playing Data: 8th column in sales_team.csv
        # Visits Data: 9th column in sales_team.csv 
        # FavoritedCount Data: 10th column in sales_team.csv
        numEntries = len(allData)

        scoredData = []

        for i in range(len(columnIndices)):
            scoredData.append([int(allData[j][columnIndices[i]]) for j in range(1, numEntries)])


        '''playingData = [int(allData[i][8]) for i in range(1, numEntries)]
        visitsData = [int(allData[i][9]) for i in range(1, numEntries)]
        favoritedCountData = [int(allData[i][10]) for i in range(1, numEntries)]'''

        numEntries -= 1

        # feature scaling will be done one playing, visits, and favoritedCount
        # will help rank games based on these variables since all of the values
        # will be between 0 and 1, inclusive

        '''self.normalize(playingData)
        self.normalize(visitsData)
        self.normalize(favoritedCountData)'''

        for i in range(len(scoredData)):
            self.normalize(scoredData[i])

        print(len(scoredData), ' ', numEntries)

        filteredData = {}

        for i in range(1, numEntries+1):
            totalScore = 0
            for j in range(len(columnIndices)):
                totalScore += scoredData[j][i-1] * weights[j]
            filteredData[allData[i][0]] = totalScore / len(columnIndices)

        print(filteredData)

        testData = sorted(filteredData.items(), key = lambda x: x[1], reverse=True)

        return testData

    def test(self):
        print("Test")
    

if __name__ == "__main__":
    robObj = filterRoblox()
    columnIndices = [8,9,10,12,13]
    weights = [1,1,1,1,1]
    fileName = 'C:\College\A&M\Courses\Clubs\Search Bar\playground\sales_team.csv'
    testData = robObj.filter(fileName, columnIndices, weights)
    print(testData[0:13])