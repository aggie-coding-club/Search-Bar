from django.shortcuts import render
from django.http.response import HttpResponse, JsonResponse
from rest_framework.response import Response
from . import views
from django.template import loader
from rest_framework import generics
from .models import Roblox
# Create your views here.

def index(request):
    # http://localhost:8000/?search=dog&genre=All,Sci-Fi
    search_results = request.GET.get("search")
    genre_filter = request.GET.get("genre") # genre_filter should be done with include
    sort_results = request.GET.get("sort") # {(+|-)category_name}

    if search_results and genre_filter:
        genre_filter = genre_filter.split(",")
        games = Roblox.objects.filter(name__search=search_results).exclude(genre__in=genre_filter)
    elif search_results:
        games = Roblox.objects.filter(name__search=search_results)
    elif genre_filter:
        genre_filter = genre_filter.split(",")
        games = Roblox.objects.exclude(genre__in=genre_filter)
    else:
        games = Roblox.objects.all()
    games = games.order_by(sort_results if sort_results else "-playing")
    games = list(games.values())
    
    #return render(request, "index.html", context)
    return JsonResponse({"data": games}, status=200)