import React, {Component, useState, useEffect} from "react";
import {Button, ButtonGroup} from "react-bootstrap"

import "bootstrap/dist/css/bootstrap.min.css";
import './App.css';
//import "C:/Users/Dien Chau/Documents/web_dev/roblox-react/node_modules/bootstrap/dist/css/bootstrap.min.css"

const axios = require('axios');
axios.defaults.baseURL = "http://localhost:8000";


function App() {
    const initialExc = {
      All: false,
      Adventure: false,
      Building: false,
      Comedy: false,
      Fighting: false,
      FPS: false,
      Horror: false,
      Medieval: false,
      Military: false,
      Naval: false,
      RPG: false,
      Sci_Fi: false,
      Sports: false,
      Town6and6City: false,
      Western: false,
    };
    const [games, setGames] = useState([]);
    const [search, setSearch] = useState("");
    // All,Adventure,Building,Comedy,Fighting,FPS,Horror,Medieval,Military,Naval,RPG,Sci-Fi,Sports,Town and City,Western
    const [genreExc, setGenreExc] = useState(initialExc);

    function handleSubmit(evt, genre_excludes = null){
      evt.preventDefault();
      console.log(search);
      let gExc = "";
      if(Boolean(genre_excludes)){
        for(const[key, val] of Object.entries(genre_excludes)){
          if(val){
            gExc += key.replaceAll("_", "-").replaceAll("6", " ") + ","
          }
        }
      }
      else{
        setGenreExc(initialExc);
      }
      const params = new URLSearchParams({
        search: search,
        genre: gExc,
      });
      axios.get(`/?` + params.toString()).then(resp => {
        console.log(resp.data);
        setGames(resp.data)
      });
    }

    function toggleOption(evt){
      const key = evt.target.value
      const tempSelected = Object.assign({}, genreExc)
      tempSelected[key] = !tempSelected[key];
      handleSubmit(evt, tempSelected);
      setGenreExc(tempSelected);
    }
    
    return (
    <div className = "app"> 
      <nav className="navbar navbar-expand navbar-dark bg-dark">
          <div className="navbar-content">
            <div className="search-container">
              <form method = "get" onSubmit={handleSubmit}>
                <input type="text" 
                name="gamename" 
                onChange={e => setSearch(e.target.value)}
                placeholder="Search"
                autoComplete="off"/>
                <input type="submit" value="search"/>
              </form>  
            </div>
            {genre_button(genreExc, toggleOption)}
          </div>
        
      </nav>

      <div className="main-container">
        <div className="sneaky-container">
          <div className="table-container">
            <table className="gameTable table table-hover" width="100%" role="grid">
              <thead className="gameHeaders">
                <tr className="header-row">
                  <th className="thumb-cell col-sm-1"></th>
                  <th className="col-sm-4">name</th>
                  <th className="col-sm-1.5">genre</th>
                  <th>playing</th>
                  <th>visits</th>
                  <th>favorites</th>
                  <th>rating</th>
                </tr>
              </thead>
              <tbody className="gamesList">
                {formatGamesTable(games)}
              </tbody>
            </table>
          </div>  
        </div>
      </div>
    </div>

    );
}

function genre_button(options, func){
  const buttonArr = [];
  for(const [key, value] of Object.entries(options)){
    buttonArr.push(
      <Button className="genre-button" onClick={func} value={key} key={key+value} genre-excluded={value.toString()}>
        {key.replaceAll("_", "-").replaceAll("6", " ")}
      </Button>
    );
  }
  return (
    <div className="genre-exclude-group">
      <ButtonGroup>
        {buttonArr}
      </ButtonGroup>
    </div>  
  );
}

function formatGamesTable(games){
  let gamesArr = games.data;
  if(gamesArr){
    let formatted = new Array(gamesArr.length);
    for(let i = 0; i < gamesArr.length; i++){
      formatted.push(
      <tr className={`gameEntry ${(i%2==1) ? "odd":"even"}`} key = {i}>
        <td><img className="gameThumb" src={gamesArr[i].thumb} height="50" width="50"/></td>
        <td><a className="gameName" href={"https://" + gamesArr[i].link} target="_blank">{gamesArr[i].name}</a></td>
        <td>{gamesArr[i].genre} </td>
        <td>{gamesArr[i].playing} </td>
        <td>{gamesArr[i].visits} </td>
        <td>{gamesArr[i].favoritedcount} </td>
        <td>{Math.round(gamesArr[i].gamerating, 1) + "%"} </td>
      </tr>
      )
    }
    return formatted;
  }
  return null;
}

export default App;
